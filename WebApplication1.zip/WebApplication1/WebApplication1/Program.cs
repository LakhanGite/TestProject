﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Hosting.WindowsServices;
using System.Diagnostics;
namespace WebApplication1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var pathToExe = Process.GetCurrentProcess().MainModule.FileName;
            var pathToContentRoot = Path.GetDirectoryName(pathToExe);
            var host = WebHost.CreateDefaultBuilder(args)
               .UseContentRoot(pathToContentRoot)
               .UseStartup<Startup>()
               .Build();

            host.RunAsService();
            BuildWebHost(args).Run();
        }

        public static IWebHost BuildWebHost(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>()
                .Build();
    }
}
//https://www.c-sharpcorner.com/article/host-an-asp-net-core-application-as-a-windows-service/
//https://docs.microsoft.com/en-us/aspnet/core/host-and-deploy/windows-service?view=aspnetcore-2.1
//https://docs.microsoft.com/en-us/aspnet/core/host-and-deploy/visual-studio-publish-profiles?view=aspnetcore-2.1&tabs=aspnetcore2x
//http://www.tutorialsteacher.com/core/target-multiple-frameworks-in-aspnet-core2
//https://stackoverflow.com/questions/45802909/updating-to-asp-net-core-2-0-packages-are-not-compatible-with-netcoreapp2-0
//