import { Person } from './person';

export var PERSONS: Person[] = [
  {"id": 27, "name": "keyur", "city": "Pune", "mobileNo": "7387029671"},
  {"id": 26, "name": "denish", "city": "Mumbai", "mobileNo": "9825216383"},
  {"id": 44, "name": "vinit", "city": "Surat", "mobileNo": "9879534778"}
]; 