export class category {
    id : number;
    categoryName : string;
    description : string;
}