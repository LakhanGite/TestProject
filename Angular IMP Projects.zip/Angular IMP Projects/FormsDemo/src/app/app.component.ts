import { Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-root',
  template: `<app-product></app-product>`,
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'app';

    @ViewChild("templateForm")
    templateForm : NgForm;


    save() : void {
        /*console.log(this.templateForm);
        console.log(this.templateForm.value);
        console.log(this.templateForm.controls['name'].value);
        console.log(this.templateForm.valid);
        console.log(this.templateForm.touched); */
        console.log('Value for Name element', this.templateForm.controls['name'].value);
        console.log('Value for City element', this.templateForm.controls['city'].value);
        console.log('Value for Age element', this.templateForm.controls['age'].value);
        console.log('Value for Gender element', this.templateForm.controls['gender'].value);
        console.log('Value for Language element', this.templateForm.controls['language'].value);
        console.log('Value for Email element', this.templateForm.controls['email'].value);
        //console.log('Value for Password element', this.templateForm.controls['password'].value);
        console.log('Form is valid', this.templateForm.valid);
        console.log('Form is invalid', this.templateForm.invalid);
        console.log('Form is pending', this.templateForm.pending);
        console.log('Form is touched', this.templateForm.touched);
        console.log('Form is untouched', this.templateForm.untouched);
        console.log('Form is pristine', this.templateForm.pristine);
        console.log('Form is dirty', this.templateForm.dirty);
    }
}
