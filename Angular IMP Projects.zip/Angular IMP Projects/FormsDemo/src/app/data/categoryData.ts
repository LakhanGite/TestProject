import { category } from '../objects/category';

export const categoryData : category [] = [
{
    "id" : 1111,
    "categoryName" : 'Electronics',
    "description" : 'All electronics products are available.'
},
{
    "id" : 2222,
    "categoryName" : 'Food',
    "description" : 'All food products are available.'
},
{
    "id" : 3333,
    "categoryName" : 'Home Appliances',
    "description" : 'All home appliances products are available.'
}
];