import { product } from '../objects/product';

export const productData : product [] = [
    {
        "id" : 111,
        "name" : 'Burger',
        "price" : 200,
        "description" : 'Veg burger',
        "quantity" : 5,
        "discount" : 5
    },
    {
        "id" : 222,
        "name" : 'Pizza',
        "price" : 450,
        "description" : 'Non veg pizza',
        "quantity" : 2,
        "discount" : 5
    },
    {
        "id" : 333,
        "name" : 'Apple',
        "price" : 150,
        "description" : 'Shimpla apples',
        "quantity" : 10,
        "discount" : 10
    }
];