import { Component, OnInit } from '@angular/core';
import { categoryData } from '../data/categoryData';
import { product } from '../objects/product';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

    categories = categoryData;
    products = new product();
   discounts : number [] = [ 5, 10 ];

    constructor() { }

  ngOnInit() {
  }

}
