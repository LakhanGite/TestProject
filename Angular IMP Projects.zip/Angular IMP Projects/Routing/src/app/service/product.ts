export class product {
    id : number;
    name :string;
    price : string;
    description : string;
    constructor(){}
}