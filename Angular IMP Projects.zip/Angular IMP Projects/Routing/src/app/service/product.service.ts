import { Injectable } from '@angular/core';
import { product } from './product';
import { PRODUCT } from './mock.product';

@Injectable()
export class ProductService {

    getAllProducts() : Promise<product[]>{
        return Promise.resolve(PRODUCT);
    }
    //Understanding JavaScript Promises. A promise represents the eventual result of an asynchronous operation. It is a placeholder into which the successful result value or reason for failure will materialize.
 //The callback takes two arguments, resolve and reject , which are both functions. All your asynchronous code goes inside that callback. If everything is successful, the promise is fulfilled by calling resolve() . In case of an error, reject() is called with an Error object. 

   getProduct(id : number) : Promise<product> {
       return this.getAllProducts().then(product=> product.find(product=> product.id === id))
   }


}
