import { product } from './product';

export var PRODUCT : product[] = [
{ id : 11, name : "laptop", price:"10000 Rs", description:"Laptop"},
{ id : 22, name : "led", price:"2000 Rs", description:"LED"},
{ id : 33, name : "hmdecorator", price:"30000 Rs", description:"Home Decorator"},
{ id : 44, name : "cosmetic", price:"4500 Rs", description:"Cosmetics"},
];

