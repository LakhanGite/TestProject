import { NgModule } from '@angular/core'
import { RouterModule , Routes } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { AddproductComponent } from './addproduct/addproduct.component';
import { ManageproductComponent } from './manageproduct/manageproduct.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { ViewdetailComponent } from './viewdetail/viewdetail.component';
import { UpdateproductComponent } from './updateproduct/updateproduct.component';

const routes : Routes = [
   { path:'home' , component:HomeComponent },
   { path:'addproduct' , component:AddproductComponent },
   { path:'manageproduct' , component:ManageproductComponent },
   { path:'viewdetail/:id' , component:ViewdetailComponent },
   { path:'updateproduct/:id' , component:UpdateproductComponent },
   { path:'' , redirectTo : '/home', pathMatch : 'full' },
   { path:'**' , component:PagenotfoundComponent },

];

@NgModule({
    imports : [ RouterModule.forRoot(routes)],
    exports : [ RouterModule]
})

export class AppRoutingModule {

}