import { Component, OnInit } from '@angular/core';
import { ActivatedRoute , Router, Params } from '@angular/router';
import { product } from '../service/product';
import { ProductService } from '../service/product.service';
import { Location } from '@angular/common';


@Component({
  selector: 'app-updateproduct',
  templateUrl: './updateproduct.component.html',
  styleUrls: ['./updateproduct.component.css']
})
export class UpdateproductComponent implements OnInit {

  product : product;
  
  constructor(private route : ActivatedRoute,
    private productService : ProductService,
    private location :Location,
    private router : Router) { }

ngOnInit() {
this.route.params
.switchMap((params : Params) => this.productService.getProduct(+params['id']) )
.subscribe(product => this.product = product);

}

goBack() :void {
this.location.back();
}

}
