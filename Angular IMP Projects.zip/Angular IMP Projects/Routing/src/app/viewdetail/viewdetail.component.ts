import { Component, OnInit } from '@angular/core';
import { ActivatedRoute , Router, Params } from '@angular/router';
import { product } from '../service/product';
import { ProductService } from '../service/product.service';
import { Location } from '@angular/common';

import 'rxjs/add/operator/switchMap';


@Component({
  selector: 'app-viewdetail',
  templateUrl: './viewdetail.component.html',
  styleUrls: ['./viewdetail.component.css']
})
export class ViewdetailComponent implements OnInit {

  product : product;
  constructor(private route : ActivatedRoute,
              private productService : ProductService,
              private location :Location,
              private router : Router) { }

  ngOnInit() {
    this.route.params
          .switchMap((params : Params) => this.productService.getProduct(+params['id']) )
          .subscribe(product => this.product = product);

  }

  goBack() :void {
   this.location.back();
  }

  updateProduct(id : number) : void {
    console.log ("in update prod");
    this.router.navigate(['/updateproduct' , id]);
  }

}
