import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CollapseModule } from 'bootstrap';
import { ProductService } from './service/product.service';
import { FormsModule } from '@angular/forms';


import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AddproductComponent } from './addproduct/addproduct.component';
import { ManageproductComponent } from './manageproduct/manageproduct.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { ViewdetailComponent } from './viewdetail/viewdetail.component';
import { UpdateproductComponent } from './updateproduct/updateproduct.component';
import { AppRoutingModule } from './app.routing.module';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AddproductComponent,
    ManageproductComponent,
    PagenotfoundComponent,
    ViewdetailComponent,
    UpdateproductComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
    //,    CollapseModule
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
