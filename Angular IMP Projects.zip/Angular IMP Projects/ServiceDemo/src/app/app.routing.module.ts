import { NgModule }      from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


import { HomeComponent }  from './home/home.component';
import { ViewdetailComponent } from './viewdetail/viewdetail.component';
import { AddpersonComponent }  from './addperson/addperson.component';
import { ManagepersonComponent }  from './manageperson/manageperson.component';
import { UpdatepersonComponent }  from './updateperson/updateperson.component';


const routes: Routes = [
    { path: 'home', component: HomeComponent },
    { path: 'viewdetail/:id', component: ViewdetailComponent },
    { path: 'add-person', component: AddpersonComponent },	
    { path: 'manage-person', component: ManagepersonComponent },	
    { path: 'update-person/:id', component: UpdatepersonComponent }, 
	{ path: '', redirectTo: '/home', pathMatch: 'full' }
];
@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule{ }