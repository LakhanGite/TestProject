import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core'; 
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AppRoutingModule } from './app.routing.module';
import { PersonService } from './service/person.service';
import { ViewdetailComponent } from './viewdetail/viewdetail.component';
import { AddpersonComponent } from './addperson/addperson.component';
import { ManagepersonComponent } from './manageperson/manageperson.component';
import { UpdatepersonComponent } from './updateperson/updateperson.component';
import { HelpComponent } from './help/help.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ViewdetailComponent,
    AddpersonComponent,
    ManagepersonComponent,
    UpdatepersonComponent,
    HelpComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [PersonService],
  bootstrap: [AppComponent]
})
export class AppModule { }
