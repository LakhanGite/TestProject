export class person {
    constructor(
        private id : Number,
        private name : String,
        private city : String,
        private phoneNumber : Number
     ){}
}