import { Injectable } from '@angular/core';

import { Http, Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';

import { Observable } from 'rxjs';

import { person } from './person';


@Injectable()

export class PersonService {

    constructor(private http: Http){

    }

    private  personUrl = 'http://localhost:3000/person';
    //PersonData : person;

    getPersonList() {
        return this.http.get(this.personUrl)
            .map(this.extractData)
           .catch(this.handleError);
    }

    private extractData(res: Response){
        return res.json();
    }

    private handleError ( error: Response | any){
        console.error(error.message || error);
        return Observable.throw(error.status);
    }

    createPerson(personData) {
        return this.http.post( this.personUrl, personData);
    }

    updatePerson(personData) {
        return this.http.put( this.personUrl+"/"+personData.id, personData);
    }

    deletePerson(personData) {
        return this.http.delete( this.personUrl+"/"+personData.id);
    }
}