import { Component, OnInit } from '@angular/core';
import { PersonService } from './person.service';
import { person } from './person';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  personList : person[];
  statusCode : number;
  userForm : FormGroup;

  constructor(private personService: PersonService) { }
  ngOnInit() {
      this.getAllPerson();

      this.userForm = new FormGroup({
          id : new FormControl(''),
          name : new FormControl('', Validators.maxLength(20)),
          city : new FormControl(),
          phoneNumber : new FormControl()
      })
  }
    onFormSubmit() : void {
        console.log(this.userForm.value);
       this.personService.updatePerson(this.userForm.value).subscribe(
            (success) => {
                console.log(success);
                this.statusCode = success.status;
                this.getAllPerson();
            },
            (error) => {console.log(error)}
        );

        getAllPerson() {
            this.personService.getPersonList().subscribe(
                data => this.personList = data,
                errorCode => this.statusCode = errorCode);
        }

       /* this.personService.updatePerson(this.userForm.value).subscribe(
            (success) => {
                console.log(success);
                this.statusCode = success.status;
                this.getAllPerson();
            },
            (error) => {console.log(error)}
        );  */

       /* this.personService.deletePerson(this.userForm.value).subscribe(
            (success) => {
                console.log(success);
                this.statusCode = success.status;
                this.getAllPerson();
            },
            (error) => {console.log(error)}
        );  */
       // console.log( 'Name:' + this.userForm.get('name').value);
       // console.log( 'Name:' + this.userForm.get('age').value);
    }

    getAllPerson() {
       // this.personService.getPersonList();
      this.personService.getPersonList().subscribe(
         // data => console.log(data.json()),
          data => this.personList = data,
          errorCode => this.statusCode = errorCode);
    }
  }

